class StaticController < ApplicationController
  def index
  end
end
